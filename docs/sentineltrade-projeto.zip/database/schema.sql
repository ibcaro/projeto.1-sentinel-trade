-- SentinelTrade: esquema relacional (SQLite). Valores monetários em centavos.

CREATE TABLE usuarios (
    id                TEXT PRIMARY KEY,
    email             TEXT NOT NULL UNIQUE,
    senha_hash        TEXT NOT NULL,
    perfil            TEXT NOT NULL CHECK (perfil IN ('INVESTIDOR', 'ADMINISTRADOR')),
    segredo_mfa       TEXT NOT NULL,
    falhas_login      INTEGER NOT NULL DEFAULT 0 CHECK (falhas_login >= 0),
    bloqueado_ate     TEXT,
    ultimo_passo_mfa  INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE contas (
    usuario_id             TEXT PRIMARY KEY REFERENCES usuarios(id),
    saldo_centavos         INTEGER NOT NULL CHECK (saldo_centavos >= 0),
    reservado_centavos     INTEGER NOT NULL DEFAULT 0 CHECK (reservado_centavos >= 0),
    limite_risco_centavos  INTEGER NOT NULL CHECK (limite_risco_centavos > 0)
);

CREATE TABLE ativos (
    simbolo  TEXT PRIMARY KEY,
    nome     TEXT NOT NULL
);

CREATE TABLE posicoes (
    usuario_id  TEXT NOT NULL REFERENCES usuarios(id),
    ativo       TEXT NOT NULL REFERENCES ativos(simbolo),
    quantidade  INTEGER NOT NULL CHECK (quantidade >= 0),
    reservada   INTEGER NOT NULL DEFAULT 0 CHECK (reservada >= 0),
    PRIMARY KEY (usuario_id, ativo),
    CHECK (reservada <= quantidade)
);

CREATE TABLE ordens (
    id                  TEXT PRIMARY KEY,
    investidor_id       TEXT NOT NULL REFERENCES usuarios(id),
    ativo               TEXT NOT NULL REFERENCES ativos(simbolo),
    tipo                TEXT NOT NULL CHECK (tipo IN ('COMPRA', 'VENDA')),
    quantidade          INTEGER NOT NULL CHECK (quantidade > 0),
    preco_centavos      INTEGER NOT NULL CHECK (preco_centavos > 0),
    chave_idempotencia  TEXT NOT NULL,
    estado              TEXT NOT NULL CHECK (estado IN
                          ('PENDENTE','ENVIADA','EXECUTADA','REJEITADA','CANCELADA','FALHA')),
    motivo              TEXT,
    criado_em           TEXT NOT NULL,
    atualizado_em       TEXT NOT NULL,
    -- impede duas ordens do mesmo investidor com a mesma chave
    UNIQUE (investidor_id, chave_idempotencia)
);

CREATE TABLE logs_auditoria (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    evento         TEXT NOT NULL,
    usuario_id     TEXT,
    detalhes       TEXT NOT NULL,
    criado_em      TEXT NOT NULL,
    hash_anterior  TEXT NOT NULL,
    hash_registro  TEXT NOT NULL
);

-- Logs imutáveis: proíbem alterar ou apagar registros.
CREATE TRIGGER logs_sem_update BEFORE UPDATE ON logs_auditoria
BEGIN
    SELECT RAISE(ABORT, 'logs de auditoria são imutáveis');
END;

CREATE TRIGGER logs_sem_delete BEFORE DELETE ON logs_auditoria
BEGIN
    SELECT RAISE(ABORT, 'logs de auditoria são imutáveis');
END;

CREATE INDEX idx_ordens_investidor ON ordens (investidor_id);
CREATE INDEX idx_logs_evento ON logs_auditoria (evento);
