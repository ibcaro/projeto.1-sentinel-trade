"""Ponto de entrada: python main.py  (documentação interativa em http://127.0.0.1:8000/docs)"""
import secrets

from sentineltrade.api.app import criar_app
from sentineltrade.configuracao import carregar_configuracao
from sentineltrade.dados_demo import SENHA_DEMO, popular_demo
from sentineltrade.integracoes.bolsa import BolsaSimulada
from sentineltrade.servicos.contexto import criar_servicos


def criar_aplicacao():
    cfg = carregar_configuracao()
    chave = cfg.chave_secreta
    if not chave:
        chave = secrets.token_urlsafe(48)
        print("AVISO: SENTINEL_CHAVE_SECRETA não definida. Usando chave temporária "
              "(os tokens deixam de valer ao reiniciar). Crie o arquivo .env a partir do .env.example.")
    servicos = criar_servicos(cfg.caminho_banco, chave, bolsa=BolsaSimulada(aberta=cfg.mercado_aberto))
    if popular_demo(servicos):
        print("Dados de demonstração criados (fictícios).")
    return criar_app(servicos), cfg


if __name__ == "__main__":
    import uvicorn

    app, cfg = criar_aplicacao()
    print(f"\nUsuários de demonstração (senha: {SENHA_DEMO}):")
    print("  investidor@orion.com   |   admin@orion.com")
    print("Código MFA atual:  python -m sentineltrade.dados_demo codigo investidor@orion.com")
    print(f"Documentação: http://{cfg.host}:{cfg.porta}/docs\n")
    uvicorn.run(app, host=cfg.host, port=cfg.porta)
