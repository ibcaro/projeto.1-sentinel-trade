"""BFF: expõe os serviços via HTTP. Só valida a entrada e delega; não tem regra de negócio."""
from fastapi import FastAPI

from .erros import registrar_erros
from .rotas import auditoria, autenticacao, ordens


def criar_app(servicos) -> FastAPI:
    """`servicos` é o objeto criado por sentineltrade.servicos.contexto.criar_servicos."""
    app = FastAPI(title="SentinelTrade", version="1.0.0",
                  description="Sistema de trade simulado da corretora fictícia Orion Capital.")
    app.state.servicos = servicos
    registrar_erros(app)
    app.include_router(autenticacao.router)
    app.include_router(ordens.router)
    app.include_router(auditoria.router)

    @app.get("/saude", tags=["Sistema"])
    def saude():
        return {"status": "ok"}

    return app
