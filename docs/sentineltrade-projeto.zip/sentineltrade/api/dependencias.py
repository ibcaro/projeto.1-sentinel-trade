"""Dependências compartilhadas: serviços e usuário autenticado."""
from fastapi import Depends, Request
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from ..dominio.excecoes import AcessoNegado, TokenInvalido
from ..dominio.modelos import Perfil, Usuario

_bearer = HTTPBearer(auto_error=False)


def obter_servicos(request: Request):
    return request.app.state.servicos


def usuario_atual(cred: HTTPAuthorizationCredentials | None = Depends(_bearer),
                  servicos=Depends(obter_servicos)) -> Usuario:
    if cred is None:
        raise TokenInvalido()
    return servicos.autenticacao.validar_token(cred.credentials)


def exigir_administrador(usuario: Usuario = Depends(usuario_atual)) -> Usuario:
    if usuario.perfil != Perfil.ADMINISTRADOR:
        raise AcessoNegado()
    return usuario
