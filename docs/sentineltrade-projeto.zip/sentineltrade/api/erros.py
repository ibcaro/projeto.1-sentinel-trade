"""Converte exceções em respostas HTTP sem expor detalhes internos."""
import logging

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from ..dominio.excecoes import ErroDeDominio

log = logging.getLogger("sentineltrade")


def registrar_erros(app: FastAPI) -> None:
    @app.exception_handler(ErroDeDominio)
    async def erro_de_dominio(_: Request, exc: ErroDeDominio) -> JSONResponse:
        return JSONResponse(status_code=exc.status_http, content={"erro": exc.mensagem_publica})

    @app.exception_handler(RequestValidationError)
    async def entrada_invalida(_: Request, __: RequestValidationError) -> JSONResponse:
        return JSONResponse(status_code=422, content={"erro": "Dados inválidos."})

    @app.exception_handler(Exception)
    async def erro_inesperado(_: Request, exc: Exception) -> JSONResponse:
        log.exception("Erro inesperado")   # detalhe só no log do servidor
        return JSONResponse(status_code=500, content={"erro": "Erro interno."})
