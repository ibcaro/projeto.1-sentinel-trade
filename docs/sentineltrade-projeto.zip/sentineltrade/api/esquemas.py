"""Modelos Pydantic: validam toda entrada da API por lista de valores permitidos."""
from decimal import Decimal
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from ..dominio.estados import EstadoOrdem
from ..dominio.modelos import TipoOrdem
from ..dominio.validacao import (PADRAO_ATIVO, PADRAO_CHAVE, PADRAO_CODIGO_MFA,
                                 PADRAO_EMAIL, QUANTIDADE_MAXIMA)


class LoginEntrada(BaseModel):
    model_config = ConfigDict(extra="forbid")
    email: str = Field(pattern=f"^{PADRAO_EMAIL}$", max_length=254)
    senha: str = Field(min_length=8, max_length=128)


class MfaEntrada(BaseModel):
    model_config = ConfigDict(extra="forbid")
    token_parcial: str = Field(min_length=10, max_length=2048)
    codigo: str = Field(pattern=f"^{PADRAO_CODIGO_MFA}$")


class TokenSaida(BaseModel):
    token: str
    etapa: Literal["mfa_pendente", "autenticado"]


class OrdemEntrada(BaseModel):
    model_config = ConfigDict(extra="forbid")
    ativo: str = Field(pattern=f"^{PADRAO_ATIVO}$")
    tipo: Literal["COMPRA", "VENDA"]
    quantidade: int = Field(gt=0, le=QUANTIDADE_MAXIMA)
    preco: Decimal = Field(gt=0, le=1_000_000, max_digits=12, decimal_places=2)
    chave_idempotencia: str = Field(pattern=f"^{PADRAO_CHAVE}$")


class OrdemSaida(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: str
    ativo: str
    tipo: TipoOrdem
    quantidade: int
    preco: Decimal
    estado: EstadoOrdem
    motivo: Optional[str] = None


class PosicaoSaida(BaseModel):
    ativo: str
    quantidade: int
    reservada: int


class CarteiraSaida(BaseModel):
    saldo: Decimal
    reservado: Decimal
    limite_risco: Decimal
    posicoes: list[PosicaoSaida]


class LogSaida(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    evento: str
    usuario_id: Optional[str] = None
    detalhes: str
    criado_em: str
    hash_registro: str


class ErroSaida(BaseModel):
    erro: str


def ordem_para_saida(ordem) -> OrdemSaida:
    """Monta a resposta explicitamente (o preço é calculado a partir dos centavos)."""
    return OrdemSaida(id=ordem.id, ativo=ordem.ativo, tipo=ordem.tipo, quantidade=ordem.quantidade,
                      preco=ordem.preco, estado=ordem.estado, motivo=ordem.motivo)
