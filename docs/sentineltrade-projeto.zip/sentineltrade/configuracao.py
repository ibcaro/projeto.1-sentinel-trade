"""Lê as configurações do ambiente e do arquivo .env (que não vai para o GitHub)."""
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Optional


@dataclass
class Configuracao:
    caminho_banco: str
    chave_secreta: Optional[str]
    host: str
    porta: int
    mercado_aberto: bool


def _ler_env(caminho: Path) -> None:
    if not caminho.exists():
        return
    for linha in caminho.read_text(encoding="utf-8").splitlines():
        linha = linha.strip()
        if not linha or linha.startswith("#") or "=" not in linha:
            continue
        chave, valor = linha.split("=", 1)
        os.environ.setdefault(chave.strip(), valor.strip().strip('"').strip("'"))


def carregar_configuracao(arquivo_env: str = ".env") -> Configuracao:
    _ler_env(Path(arquivo_env))
    return Configuracao(
        caminho_banco=os.environ.get("SENTINEL_BANCO", "sentineltrade.db"),
        chave_secreta=os.environ.get("SENTINEL_CHAVE_SECRETA") or None,
        host=os.environ.get("SENTINEL_HOST", "127.0.0.1"),
        porta=int(os.environ.get("SENTINEL_PORTA", "8000")),
        mercado_aberto=os.environ.get("BOLSA_MERCADO_ABERTO", "true").lower() == "true",
    )
