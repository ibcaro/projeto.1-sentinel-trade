"""Cadastro de usuários e dados de demonstração (tudo fictício).

Uso:  python -m sentineltrade.dados_demo codigo investidor@orion.com
      (mostra o código MFA atual desse usuário, para a demonstração)
"""
import sys
import uuid
from typing import Optional

from .dominio.modelos import Conta, Perfil, Usuario
from .dominio.validacao import validar_email, validar_senha
from .servicos.contexto import Servicos
from .servicos.seguranca import gerar_codigo, gerar_segredo_mfa, hash_senha

SENHA_DEMO = "Senha@12345"
SEGREDO_INVESTIDOR_DEMO = "JBSWY3DPEHPK3PXP"
SEGREDO_ADMIN_DEMO = "KRSXG5CTMVRXEZLU"


def cadastrar_usuario(s: Servicos, email: str, senha: str, perfil: Perfil,
                      saldo_centavos: Optional[int] = None,
                      limite_risco_centavos: Optional[int] = None,
                      segredo_mfa: Optional[str] = None) -> Usuario:
    usuario = Usuario(id=str(uuid.uuid4()), email=validar_email(email),
                      senha_hash=hash_senha(validar_senha(senha)), perfil=perfil,
                      segredo_mfa=segredo_mfa or gerar_segredo_mfa())
    with s.banco.transacao():
        s.repo_usuarios.criar(usuario)
        if perfil == Perfil.INVESTIDOR:
            s.repo_contas.criar_conta(Conta(usuario.id, saldo_centavos or 0, 0,
                                            limite_risco_centavos or 1))
    return usuario


def popular_demo(s: Servicos) -> bool:
    """Cria os dados de demonstração se o banco estiver vazio. Devolve True se criou."""
    if s.repo_usuarios.contar() > 0:
        return False
    for simbolo, nome in (("PETR4", "Petrobras PN"), ("VALE3", "Vale ON"), ("ITUB4", "Itaú Unibanco PN")):
        s.repo_contas.criar_ativo(simbolo, nome)
    inv = cadastrar_usuario(s, "investidor@orion.com", SENHA_DEMO, Perfil.INVESTIDOR,
                            saldo_centavos=10_000_000, limite_risco_centavos=5_000_000,
                            segredo_mfa=SEGREDO_INVESTIDOR_DEMO)   # R$ 100.000 / limite R$ 50.000
    s.repo_contas.ajustar_posicao(inv.id, "PETR4", 200, 0)
    s.repo_contas.ajustar_posicao(inv.id, "VALE3", 100, 0)
    cadastrar_usuario(s, "admin@orion.com", SENHA_DEMO, Perfil.ADMINISTRADOR,
                      segredo_mfa=SEGREDO_ADMIN_DEMO)
    return True


def _cli() -> None:
    from .configuracao import carregar_configuracao
    from .servicos.contexto import criar_servicos
    if len(sys.argv) != 3 or sys.argv[1] != "codigo":
        print("Uso: python -m sentineltrade.dados_demo codigo <email>")
        return
    cfg = carregar_configuracao()
    s = criar_servicos(cfg.caminho_banco, cfg.chave_secreta or ("x" * 32))
    usuario = s.repo_usuarios.obter_por_email(sys.argv[2].lower())
    if usuario is None:
        print("Usuário não encontrado. Rode antes: python main.py")
        return
    print(gerar_codigo(usuario.segredo_mfa, s.relogio()))


if __name__ == "__main__":
    _cli()
