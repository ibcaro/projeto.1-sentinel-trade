"""Ciclo de vida da ordem: estados e transições permitidas."""
from enum import Enum

from .excecoes import TransicaoInvalida


class EstadoOrdem(str, Enum):
    PENDENTE = "PENDENTE"
    ENVIADA = "ENVIADA"
    EXECUTADA = "EXECUTADA"
    REJEITADA = "REJEITADA"
    CANCELADA = "CANCELADA"
    FALHA = "FALHA"


E = EstadoOrdem

TRANSICOES: dict[EstadoOrdem, frozenset[EstadoOrdem]] = {
    E.PENDENTE: frozenset({E.ENVIADA, E.REJEITADA, E.CANCELADA, E.FALHA}),
    E.ENVIADA: frozenset({E.EXECUTADA, E.REJEITADA, E.CANCELADA, E.FALHA}),
    E.EXECUTADA: frozenset(),
    E.REJEITADA: frozenset(),
    E.CANCELADA: frozenset(),
    E.FALHA: frozenset(),
}

ESTADOS_FINAIS = frozenset(e for e, destinos in TRANSICOES.items() if not destinos)


def pode_transitar(origem: EstadoOrdem, destino: EstadoOrdem) -> bool:
    return destino in TRANSICOES[origem]


def validar_transicao(origem: EstadoOrdem, destino: EstadoOrdem) -> None:
    if not pode_transitar(origem, destino):
        raise TransicaoInvalida(
            f"Transição não permitida: {origem.value} -> {destino.value}."
        )
