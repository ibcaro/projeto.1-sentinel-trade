"""Hierarquia de exceções do domínio.

Cada exceção tem uma mensagem pública (segura para o usuário) e o status HTTP
que a API deve devolver. Detalhes internos nunca saem na resposta.
"""


class ErroDeDominio(Exception):
    status_http = 400
    mensagem_publica = "Requisição inválida."

    def __init__(self, mensagem: str | None = None):
        self.mensagem_publica = mensagem or type(self).mensagem_publica
        super().__init__(self.mensagem_publica)


class ValidacaoInvalida(ErroDeDominio):
    status_http = 422
    mensagem_publica = "Dados inválidos."


class CredenciaisInvalidas(ErroDeDominio):
    status_http = 401
    mensagem_publica = "Credenciais inválidas."


class ContaBloqueada(ErroDeDominio):
    status_http = 423
    mensagem_publica = "Conta temporariamente bloqueada."


class CodigoMfaInvalido(ErroDeDominio):
    status_http = 401
    mensagem_publica = "Código de verificação inválido."


class TokenInvalido(ErroDeDominio):
    status_http = 401
    mensagem_publica = "Sessão inválida ou expirada."


class AcessoNegado(ErroDeDominio):
    status_http = 403
    mensagem_publica = "Acesso negado."


class SaldoInsuficiente(ErroDeDominio):
    status_http = 422
    mensagem_publica = "Saldo insuficiente."


class PosicaoInsuficiente(ErroDeDominio):
    status_http = 422
    mensagem_publica = "Posição insuficiente."


class LimiteRiscoExcedido(ErroDeDominio):
    status_http = 422
    mensagem_publica = "Limite de risco excedido."


class MercadoFechado(ErroDeDominio):
    status_http = 422
    mensagem_publica = "Mercado fechado."


class TransicaoInvalida(ErroDeDominio):
    status_http = 409
    mensagem_publica = "Operação não permitida no estado atual da ordem."


class OrdemNaoEncontrada(ErroDeDominio):
    status_http = 404
    mensagem_publica = "Ordem não encontrada."


class BolsaIndisponivel(ErroDeDominio):
    status_http = 503
    mensagem_publica = "Bolsa indisponível."
