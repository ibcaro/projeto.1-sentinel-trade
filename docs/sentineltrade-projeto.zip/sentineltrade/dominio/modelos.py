"""Classes do negócio (análise/projeto)."""
from dataclasses import dataclass
from datetime import datetime
from decimal import Decimal
from enum import Enum
from typing import Optional

from .estados import EstadoOrdem


class Perfil(str, Enum):
    INVESTIDOR = "INVESTIDOR"
    ADMINISTRADOR = "ADMINISTRADOR"


class TipoOrdem(str, Enum):
    COMPRA = "COMPRA"
    VENDA = "VENDA"


@dataclass
class Usuario:
    id: str
    email: str
    senha_hash: str
    perfil: Perfil
    segredo_mfa: str
    falhas_login: int = 0
    bloqueado_ate: Optional[datetime] = None
    ultimo_passo_mfa: int = 0


@dataclass
class Conta:
    usuario_id: str
    saldo_centavos: int
    reservado_centavos: int
    limite_risco_centavos: int


@dataclass
class Posicao:
    usuario_id: str
    ativo: str
    quantidade: int
    reservada: int


@dataclass
class Ordem:
    id: str
    investidor_id: str
    ativo: str
    tipo: TipoOrdem
    quantidade: int
    preco_centavos: int
    chave_idempotencia: str
    estado: EstadoOrdem
    motivo: Optional[str]
    criado_em: str

    @property
    def valor_centavos(self) -> int:
        return self.quantidade * self.preco_centavos

    @property
    def preco(self) -> Decimal:
        return Decimal(self.preco_centavos) / 100


@dataclass
class LogAuditoria:
    id: int
    evento: str
    usuario_id: Optional[str]
    detalhes: str
    criado_em: str
    hash_anterior: str
    hash_registro: str
