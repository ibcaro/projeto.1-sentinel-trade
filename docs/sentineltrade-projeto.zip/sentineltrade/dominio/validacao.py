"""Validação de entradas por lista de valores permitidos (allowlist)."""
import re
from decimal import Decimal, InvalidOperation

from .excecoes import ValidacaoInvalida
from .modelos import TipoOrdem

PADRAO_EMAIL = r"[A-Za-z0-9._%+\-]{1,64}@[A-Za-z0-9.\-]{1,200}\.[A-Za-z]{2,}"
PADRAO_ATIVO = r"[A-Z0-9]{3,10}"
PADRAO_CHAVE = r"[A-Za-z0-9\-_]{8,64}"
PADRAO_CODIGO_MFA = r"[0-9]{6}"
PADRAO_EVENTO = r"[A-Z_]{3,40}"

QUANTIDADE_MAXIMA = 1_000_000
PRECO_MAXIMO = Decimal("1000000")


def _casar(padrao: str, valor, nome: str) -> str:
    if not isinstance(valor, str) or not re.fullmatch(padrao, valor):
        raise ValidacaoInvalida(f"{nome} inválido.")
    return valor


def validar_email(valor) -> str:
    return _casar(PADRAO_EMAIL, valor, "E-mail").lower()


def validar_senha(valor) -> str:
    if not isinstance(valor, str) or not 8 <= len(valor) <= 128:
        raise ValidacaoInvalida("Senha inválida.")
    return valor


def validar_ativo(valor) -> str:
    return _casar(PADRAO_ATIVO, valor, "Ativo")


def validar_chave(valor) -> str:
    return _casar(PADRAO_CHAVE, valor, "Chave de idempotência")


def validar_codigo_mfa(valor) -> str:
    return _casar(PADRAO_CODIGO_MFA, valor, "Código")


def validar_evento(valor) -> str:
    return _casar(PADRAO_EVENTO, valor, "Evento")


def validar_tipo(valor) -> TipoOrdem:
    if isinstance(valor, TipoOrdem):
        return valor
    if valor not in {t.value for t in TipoOrdem}:
        raise ValidacaoInvalida("Tipo de ordem inválido.")
    return TipoOrdem(valor)


def validar_quantidade(valor) -> int:
    if isinstance(valor, bool) or not isinstance(valor, int):
        raise ValidacaoInvalida("Quantidade inválida.")
    if not 1 <= valor <= QUANTIDADE_MAXIMA:
        raise ValidacaoInvalida("Quantidade fora do limite permitido.")
    return valor


def validar_preco(valor) -> int:
    """Valida o preço e devolve em centavos (inteiro)."""
    if isinstance(valor, bool):
        raise ValidacaoInvalida("Preço inválido.")
    try:
        preco = Decimal(str(valor))
    except InvalidOperation:
        raise ValidacaoInvalida("Preço inválido.") from None
    if not preco.is_finite() or preco <= 0 or preco > PRECO_MAXIMO:
        raise ValidacaoInvalida("Preço fora do limite permitido.")
    if preco.as_tuple().exponent < -2:
        raise ValidacaoInvalida("Preço aceita no máximo 2 casas decimais.")
    return int(preco * 100)
