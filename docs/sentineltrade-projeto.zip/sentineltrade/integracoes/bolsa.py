"""Interface da Bolsa e a implementação simulada (sem dinheiro real)."""
from abc import ABC, abstractmethod

from ..dominio.estados import EstadoOrdem
from ..dominio.excecoes import BolsaIndisponivel
from ..dominio.modelos import TipoOrdem


class Bolsa(ABC):
    @abstractmethod
    def mercado_aberto(self) -> bool: ...

    @abstractmethod
    def enviar_ordem(self, ordem_id: str, ativo: str, tipo: TipoOrdem,
                     quantidade: int, preco_centavos: int) -> EstadoOrdem:
        """Devolve EXECUTADA ou REJEITADA. Levanta BolsaIndisponivel se estiver fora do ar."""

    @abstractmethod
    def cancelar_ordem(self, ordem_id: str) -> bool: ...


class BolsaSimulada(Bolsa):
    """Bolsa de mentira, configurável para os testes e a demonstração."""

    def __init__(self, aberta: bool = True, fora_do_ar: bool = False,
                 falhas_iniciais: int = 0, resultado: EstadoOrdem = EstadoOrdem.EXECUTADA,
                 aceita_cancelamento: bool = True):
        self.aberta = aberta
        self.fora_do_ar = fora_do_ar
        self.falhas_restantes = falhas_iniciais
        self.resultado = resultado
        self.aceita_cancelamento = aceita_cancelamento
        self.tentativas = 0          # quantas vezes tentaram enviar
        self.recebidas: dict[str, EstadoOrdem] = {}   # ordem_id -> resultado (idempotente)

    def mercado_aberto(self) -> bool:
        return self.aberta

    def enviar_ordem(self, ordem_id, ativo, tipo, quantidade, preco_centavos) -> EstadoOrdem:
        self.tentativas += 1
        if self.fora_do_ar:
            raise BolsaIndisponivel()
        if self.falhas_restantes > 0:
            self.falhas_restantes -= 1
            raise BolsaIndisponivel()
        # a mesma ordem enviada duas vezes devolve o mesmo resultado, sem duplicar
        return self.recebidas.setdefault(ordem_id, self.resultado)

    def cancelar_ordem(self, ordem_id: str) -> bool:
        if self.recebidas.get(ordem_id) == EstadoOrdem.EXECUTADA:
            return False
        return self.aceita_cancelamento
