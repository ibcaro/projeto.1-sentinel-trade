"""Acesso ao SQLite. Toda consulta usa parâmetros (nunca concatenação de texto)."""
import sqlite3
import threading
from contextlib import contextmanager
from pathlib import Path

ESQUEMA = Path(__file__).resolve().parents[2] / "database" / "schema.sql"


class Banco:
    def __init__(self, caminho: str = ":memory:"):
        self._conn = sqlite3.connect(caminho, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        self._trava = threading.RLock()
        self._nivel = 0

    def criar_esquema_se_necessario(self) -> None:
        with self._trava:
            existe = self._conn.execute(
                "SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'usuarios'"
            ).fetchone()
            if not existe:
                self._conn.executescript(ESQUEMA.read_text(encoding="utf-8"))

    def executar(self, sql: str, params: tuple = ()):
        with self._trava:
            return self._conn.execute(sql, params)

    def um(self, sql: str, params: tuple = ()):
        with self._trava:
            return self._conn.execute(sql, params).fetchone()

    def todos(self, sql: str, params: tuple = ()):
        with self._trava:
            return self._conn.execute(sql, params).fetchall()

    @contextmanager
    def transacao(self):
        with self._trava:
            externa = self._nivel > 0
            if not externa:
                self._conn.execute("BEGIN")
            self._nivel += 1
            try:
                yield
            except BaseException:
                self._nivel -= 1
                if not externa:
                    self._conn.execute("ROLLBACK")
                raise
            else:
                self._nivel -= 1
                if not externa:
                    self._conn.execute("COMMIT")

    def fechar(self) -> None:
        self._conn.close()
