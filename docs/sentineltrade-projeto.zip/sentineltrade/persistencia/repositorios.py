"""Interfaces dos repositórios e implementações SQLite."""
from abc import ABC, abstractmethod
from datetime import datetime
from typing import Optional

from ..dominio.estados import EstadoOrdem
from ..dominio.modelos import (Conta, LogAuditoria, Ordem, Perfil, Posicao,
                               TipoOrdem, Usuario)
from .banco import Banco


# ---------- Interfaces ----------
class RepositorioUsuarios(ABC):
    @abstractmethod
    def criar(self, usuario: Usuario) -> None: ...
    @abstractmethod
    def obter_por_email(self, email: str) -> Optional[Usuario]: ...
    @abstractmethod
    def obter_por_id(self, usuario_id: str) -> Optional[Usuario]: ...
    @abstractmethod
    def atualizar_login(self, usuario_id: str, falhas: int,
                        bloqueado_ate: Optional[datetime]) -> None: ...
    @abstractmethod
    def atualizar_passo_mfa(self, usuario_id: str, passo: int) -> None: ...
    @abstractmethod
    def contar(self) -> int: ...


class RepositorioContas(ABC):
    @abstractmethod
    def criar_conta(self, conta: Conta) -> None: ...
    @abstractmethod
    def obter_conta(self, usuario_id: str) -> Optional[Conta]: ...
    @abstractmethod
    def ajustar_conta(self, usuario_id: str, delta_saldo: int, delta_reservado: int) -> None: ...
    @abstractmethod
    def criar_ativo(self, simbolo: str, nome: str) -> None: ...
    @abstractmethod
    def ativo_existe(self, simbolo: str) -> bool: ...
    @abstractmethod
    def obter_posicao(self, usuario_id: str, ativo: str) -> Optional[Posicao]: ...
    @abstractmethod
    def ajustar_posicao(self, usuario_id: str, ativo: str, delta_qtd: int, delta_res: int) -> None: ...
    @abstractmethod
    def listar_posicoes(self, usuario_id: str) -> list[Posicao]: ...


class RepositorioOrdens(ABC):
    @abstractmethod
    def criar(self, ordem: Ordem, agora: str) -> None: ...
    @abstractmethod
    def obter(self, ordem_id: str) -> Optional[Ordem]: ...
    @abstractmethod
    def obter_por_chave(self, investidor_id: str, chave: str) -> Optional[Ordem]: ...
    @abstractmethod
    def atualizar_estado(self, ordem_id: str, estado: EstadoOrdem,
                         motivo: Optional[str], agora: str) -> None: ...
    @abstractmethod
    def listar_por_investidor(self, investidor_id: str) -> list[Ordem]: ...


class RepositorioAuditoria(ABC):
    @abstractmethod
    def ultimo_hash(self) -> Optional[str]: ...
    @abstractmethod
    def inserir(self, evento: str, usuario_id: Optional[str], detalhes: str,
                criado_em: str, hash_anterior: str, hash_registro: str) -> int: ...
    @abstractmethod
    def listar(self, evento: Optional[str], limite: int) -> list[LogAuditoria]: ...
    @abstractmethod
    def todos_em_ordem(self) -> list[LogAuditoria]: ...


# ---------- Implementações SQLite ----------
class UsuariosSqlite(RepositorioUsuarios):
    def __init__(self, banco: Banco):
        self._b = banco

    @staticmethod
    def _montar(r) -> Usuario:
        return Usuario(
            id=r["id"], email=r["email"], senha_hash=r["senha_hash"],
            perfil=Perfil(r["perfil"]), segredo_mfa=r["segredo_mfa"],
            falhas_login=r["falhas_login"],
            bloqueado_ate=datetime.fromisoformat(r["bloqueado_ate"]) if r["bloqueado_ate"] else None,
            ultimo_passo_mfa=r["ultimo_passo_mfa"],
        )

    def criar(self, u: Usuario) -> None:
        self._b.executar(
            "INSERT INTO usuarios (id, email, senha_hash, perfil, segredo_mfa) VALUES (?, ?, ?, ?, ?)",
            (u.id, u.email, u.senha_hash, u.perfil.value, u.segredo_mfa))

    def obter_por_email(self, email: str) -> Optional[Usuario]:
        r = self._b.um("SELECT * FROM usuarios WHERE email = ?", (email,))
        return self._montar(r) if r else None

    def obter_por_id(self, usuario_id: str) -> Optional[Usuario]:
        r = self._b.um("SELECT * FROM usuarios WHERE id = ?", (usuario_id,))
        return self._montar(r) if r else None

    def atualizar_login(self, usuario_id, falhas, bloqueado_ate) -> None:
        self._b.executar(
            "UPDATE usuarios SET falhas_login = ?, bloqueado_ate = ? WHERE id = ?",
            (falhas, bloqueado_ate.isoformat() if bloqueado_ate else None, usuario_id))

    def atualizar_passo_mfa(self, usuario_id: str, passo: int) -> None:
        self._b.executar("UPDATE usuarios SET ultimo_passo_mfa = ? WHERE id = ?", (passo, usuario_id))

    def contar(self) -> int:
        return self._b.um("SELECT COUNT(*) AS n FROM usuarios")["n"]


class ContasSqlite(RepositorioContas):
    def __init__(self, banco: Banco):
        self._b = banco

    def criar_conta(self, c: Conta) -> None:
        self._b.executar(
            "INSERT INTO contas (usuario_id, saldo_centavos, reservado_centavos, limite_risco_centavos) "
            "VALUES (?, ?, ?, ?)",
            (c.usuario_id, c.saldo_centavos, c.reservado_centavos, c.limite_risco_centavos))

    def obter_conta(self, usuario_id: str) -> Optional[Conta]:
        r = self._b.um("SELECT * FROM contas WHERE usuario_id = ?", (usuario_id,))
        return Conta(r["usuario_id"], r["saldo_centavos"], r["reservado_centavos"],
                     r["limite_risco_centavos"]) if r else None

    def ajustar_conta(self, usuario_id, delta_saldo, delta_reservado) -> None:
        self._b.executar(
            "UPDATE contas SET saldo_centavos = saldo_centavos + ?, "
            "reservado_centavos = reservado_centavos + ? WHERE usuario_id = ?",
            (delta_saldo, delta_reservado, usuario_id))

    def criar_ativo(self, simbolo: str, nome: str) -> None:
        self._b.executar("INSERT OR IGNORE INTO ativos (simbolo, nome) VALUES (?, ?)", (simbolo, nome))

    def ativo_existe(self, simbolo: str) -> bool:
        return self._b.um("SELECT 1 FROM ativos WHERE simbolo = ?", (simbolo,)) is not None

    def obter_posicao(self, usuario_id, ativo) -> Optional[Posicao]:
        r = self._b.um("SELECT * FROM posicoes WHERE usuario_id = ? AND ativo = ?", (usuario_id, ativo))
        return Posicao(r["usuario_id"], r["ativo"], r["quantidade"], r["reservada"]) if r else None

    def ajustar_posicao(self, usuario_id, ativo, delta_qtd, delta_res) -> None:
        with self._b.transacao():
            cur = self._b.executar(
                "UPDATE posicoes SET quantidade = quantidade + ?, reservada = reservada + ? "
                "WHERE usuario_id = ? AND ativo = ?", (delta_qtd, delta_res, usuario_id, ativo))
            if cur.rowcount == 0:
                self._b.executar(
                    "INSERT INTO posicoes (usuario_id, ativo, quantidade, reservada) VALUES (?, ?, ?, ?)",
                    (usuario_id, ativo, delta_qtd, delta_res))

    def listar_posicoes(self, usuario_id: str) -> list[Posicao]:
        rs = self._b.todos("SELECT * FROM posicoes WHERE usuario_id = ? ORDER BY ativo", (usuario_id,))
        return [Posicao(r["usuario_id"], r["ativo"], r["quantidade"], r["reservada"]) for r in rs]


class OrdensSqlite(RepositorioOrdens):
    def __init__(self, banco: Banco):
        self._b = banco

    @staticmethod
    def _montar(r) -> Ordem:
        return Ordem(
            id=r["id"], investidor_id=r["investidor_id"], ativo=r["ativo"],
            tipo=TipoOrdem(r["tipo"]), quantidade=r["quantidade"],
            preco_centavos=r["preco_centavos"], chave_idempotencia=r["chave_idempotencia"],
            estado=EstadoOrdem(r["estado"]), motivo=r["motivo"], criado_em=r["criado_em"])

    def criar(self, o: Ordem, agora: str) -> None:
        self._b.executar(
            "INSERT INTO ordens (id, investidor_id, ativo, tipo, quantidade, preco_centavos, "
            "chave_idempotencia, estado, motivo, criado_em, atualizado_em) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
            (o.id, o.investidor_id, o.ativo, o.tipo.value, o.quantidade, o.preco_centavos,
             o.chave_idempotencia, o.estado.value, o.motivo, o.criado_em, agora))

    def obter(self, ordem_id: str) -> Optional[Ordem]:
        r = self._b.um("SELECT * FROM ordens WHERE id = ?", (ordem_id,))
        return self._montar(r) if r else None

    def obter_por_chave(self, investidor_id: str, chave: str) -> Optional[Ordem]:
        r = self._b.um("SELECT * FROM ordens WHERE investidor_id = ? AND chave_idempotencia = ?",
                       (investidor_id, chave))
        return self._montar(r) if r else None

    def atualizar_estado(self, ordem_id, estado, motivo, agora) -> None:
        self._b.executar(
            "UPDATE ordens SET estado = ?, motivo = ?, atualizado_em = ? WHERE id = ?",
            (estado.value, motivo, agora, ordem_id))

    def listar_por_investidor(self, investidor_id: str) -> list[Ordem]:
        rs = self._b.todos("SELECT * FROM ordens WHERE investidor_id = ? ORDER BY criado_em, rowid",
                           (investidor_id,))
        return [self._montar(r) for r in rs]


class AuditoriaSqlite(RepositorioAuditoria):
    def __init__(self, banco: Banco):
        self._b = banco

    @staticmethod
    def _montar(r) -> LogAuditoria:
        return LogAuditoria(r["id"], r["evento"], r["usuario_id"], r["detalhes"],
                            r["criado_em"], r["hash_anterior"], r["hash_registro"])

    def ultimo_hash(self) -> Optional[str]:
        r = self._b.um("SELECT hash_registro FROM logs_auditoria ORDER BY id DESC LIMIT 1")
        return r["hash_registro"] if r else None

    def inserir(self, evento, usuario_id, detalhes, criado_em, hash_anterior, hash_registro) -> int:
        cur = self._b.executar(
            "INSERT INTO logs_auditoria (evento, usuario_id, detalhes, criado_em, hash_anterior, hash_registro) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (evento, usuario_id, detalhes, criado_em, hash_anterior, hash_registro))
        return cur.lastrowid

    def listar(self, evento: Optional[str], limite: int) -> list[LogAuditoria]:
        if evento:
            rs = self._b.todos("SELECT * FROM logs_auditoria WHERE evento = ? ORDER BY id DESC LIMIT ?",
                               (evento, limite))
        else:
            rs = self._b.todos("SELECT * FROM logs_auditoria ORDER BY id DESC LIMIT ?", (limite,))
        return [self._montar(r) for r in rs]

    def todos_em_ordem(self) -> list[LogAuditoria]:
        return [self._montar(r) for r in self._b.todos("SELECT * FROM logs_auditoria ORDER BY id")]
