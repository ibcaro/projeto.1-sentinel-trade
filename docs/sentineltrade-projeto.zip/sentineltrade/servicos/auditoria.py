"""Log de auditoria imutável: cada registro guarda o hash do anterior."""
import hashlib
from datetime import datetime, timezone
from typing import Callable, Optional

from ..dominio.excecoes import AcessoNegado
from ..dominio.modelos import LogAuditoria, Perfil, Usuario
from ..dominio.validacao import validar_evento
from ..persistencia.banco import Banco
from ..persistencia.repositorios import RepositorioAuditoria

HASH_INICIAL = "0" * 64


def calcular_hash(anterior: str, evento: str, usuario_id: Optional[str],
                  detalhes: str, criado_em: str) -> str:
    base = "|".join([anterior, evento, usuario_id or "", detalhes, criado_em])
    return hashlib.sha256(base.encode()).hexdigest()


class ServicoAuditoria:
    def __init__(self, banco: Banco, repo: RepositorioAuditoria,
                 relogio: Callable[[], datetime] = lambda: datetime.now(timezone.utc)):
        self._banco = banco
        self._repo = repo
        self._relogio = relogio

    def registrar(self, evento: str, usuario_id: Optional[str] = None, detalhes: str = "") -> None:
        """Nunca receba senhas, códigos ou tokens em `detalhes`."""
        with self._banco.transacao():
            anterior = self._repo.ultimo_hash() or HASH_INICIAL
            criado_em = self._relogio().isoformat()
            novo = calcular_hash(anterior, evento, usuario_id, detalhes, criado_em)
            self._repo.inserir(evento, usuario_id, detalhes, criado_em, anterior, novo)

    def consultar(self, solicitante: Usuario, evento: Optional[str] = None,
                  limite: int = 50) -> list[LogAuditoria]:
        if solicitante.perfil != Perfil.ADMINISTRADOR:
            raise AcessoNegado()
        if evento is not None:
            evento = validar_evento(evento)
        limite = max(1, min(int(limite), 200))
        self.registrar("LOGS_CONSULTADOS", solicitante.id, f"filtro={evento or '-'}")
        return self._repo.listar(evento, limite)

    def verificar_integridade(self) -> tuple[bool, Optional[int]]:
        """(True, None) se a cadeia está íntegra; (False, id) no primeiro registro adulterado."""
        esperado_anterior = HASH_INICIAL
        for log in self._repo.todos_em_ordem():
            recalculado = calcular_hash(log.hash_anterior, log.evento, log.usuario_id,
                                        log.detalhes, log.criado_em)
            if log.hash_anterior != esperado_anterior or log.hash_registro != recalculado:
                return False, log.id
            esperado_anterior = log.hash_registro
        return True, None
