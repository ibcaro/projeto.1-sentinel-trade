"""Login com senha + segundo fator, bloqueio por tentativas e tokens."""
from datetime import datetime, timedelta, timezone
from typing import Callable

from ..dominio.excecoes import (CodigoMfaInvalido, ContaBloqueada,
                                CredenciaisInvalidas, TokenInvalido)
from ..dominio.modelos import Usuario
from ..dominio.validacao import validar_codigo_mfa, validar_email, validar_senha
from ..persistencia.repositorios import RepositorioUsuarios
from .auditoria import ServicoAuditoria
from .seguranca import EmissorToken, verificar_codigo, verificar_senha

MAX_FALHAS = 5
BLOQUEIO = timedelta(minutes=15)
VALIDADE_TOKEN_MFA = 5 * 60          # token parcial: 5 minutos
VALIDADE_TOKEN_ACESSO = 15 * 60      # token de acesso: 15 minutos


class ServicoAutenticacao:
    def __init__(self, usuarios: RepositorioUsuarios, auditoria: ServicoAuditoria,
                 emissor: EmissorToken,
                 relogio: Callable[[], datetime] = lambda: datetime.now(timezone.utc)):
        self._usuarios = usuarios
        self._auditoria = auditoria
        self._emissor = emissor
        self._relogio = relogio

    def login(self, email: str, senha: str) -> str:
        """Passo 1: confere e-mail e senha. Devolve um token parcial (etapa MFA)."""
        email = validar_email(email)
        senha = validar_senha(senha)
        agora = self._relogio()
        usuario = self._usuarios.obter_por_email(email)

        if usuario is None:  # mesma resposta de senha errada: não revela se o e-mail existe
            self._auditoria.registrar("LOGIN_FALHA", None, "usuario_desconhecido")
            raise CredenciaisInvalidas()

        if usuario.bloqueado_ate and agora < usuario.bloqueado_ate:
            self._auditoria.registrar("LOGIN_BLOQUEADO", usuario.id, "tentativa_durante_bloqueio")
            raise ContaBloqueada()

        if not verificar_senha(senha, usuario.senha_hash):
            falhas = usuario.falhas_login + 1
            if falhas >= MAX_FALHAS:
                self._usuarios.atualizar_login(usuario.id, 0, agora + BLOQUEIO)
                self._auditoria.registrar("CONTA_BLOQUEADA", usuario.id, f"apos_{MAX_FALHAS}_falhas")
                raise ContaBloqueada()
            self._usuarios.atualizar_login(usuario.id, falhas, None)
            self._auditoria.registrar("LOGIN_FALHA", usuario.id, f"falhas={falhas}")
            raise CredenciaisInvalidas()

        self._usuarios.atualizar_login(usuario.id, 0, None)
        self._auditoria.registrar("LOGIN_OK", usuario.id, "aguardando_mfa")
        return self._emissor.emitir(usuario.id, "mfa", VALIDADE_TOKEN_MFA, agora)

    def verificar_mfa(self, token_parcial: str, codigo: str) -> str:
        """Passo 2: confere o código de uso único. Devolve o token de acesso."""
        codigo = validar_codigo_mfa(codigo)
        agora = self._relogio()
        usuario_id = self._emissor.validar(token_parcial, "mfa", agora)
        usuario = self._usuarios.obter_por_id(usuario_id)
        if usuario is None:
            raise TokenInvalido()

        passo = verificar_codigo(usuario.segredo_mfa, codigo, agora, usuario.ultimo_passo_mfa)
        if passo is None:
            self._auditoria.registrar("MFA_FALHA", usuario.id, "codigo_invalido_ou_ja_usado")
            raise CodigoMfaInvalido()

        self._usuarios.atualizar_passo_mfa(usuario.id, passo)
        self._auditoria.registrar("MFA_OK", usuario.id, "acesso_liberado")
        return self._emissor.emitir(usuario.id, "acesso", VALIDADE_TOKEN_ACESSO, agora)

    def validar_token(self, token: str) -> Usuario:
        usuario_id = self._emissor.validar(token, "acesso", self._relogio())
        usuario = self._usuarios.obter_por_id(usuario_id)
        if usuario is None:
            raise TokenInvalido()
        return usuario
