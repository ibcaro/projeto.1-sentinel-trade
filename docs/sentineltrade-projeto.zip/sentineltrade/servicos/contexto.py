"""Monta todos os serviços (injeção de dependências)."""
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Callable, Optional

from ..integracoes.bolsa import Bolsa, BolsaSimulada
from ..persistencia.banco import Banco
from ..persistencia.repositorios import (AuditoriaSqlite, ContasSqlite,
                                         OrdensSqlite, UsuariosSqlite)
from .auditoria import ServicoAuditoria
from .autenticacao import ServicoAutenticacao
from .ordem import ServicoOrdem
from .seguranca import EmissorToken


@dataclass
class Servicos:
    banco: Banco
    bolsa: Bolsa
    relogio: Callable[[], datetime]
    repo_usuarios: UsuariosSqlite
    repo_contas: ContasSqlite
    repo_ordens: OrdensSqlite
    repo_auditoria: AuditoriaSqlite
    auditoria: ServicoAuditoria
    autenticacao: ServicoAutenticacao
    ordens: ServicoOrdem


def _agora() -> datetime:
    return datetime.now(timezone.utc)


def criar_servicos(caminho_banco: str, chave_secreta: str, bolsa: Optional[Bolsa] = None,
                   relogio: Optional[Callable[[], datetime]] = None) -> Servicos:
    relogio = relogio or _agora
    bolsa = bolsa or BolsaSimulada()
    banco = Banco(caminho_banco)
    banco.criar_esquema_se_necessario()

    repo_usuarios = UsuariosSqlite(banco)
    repo_contas = ContasSqlite(banco)
    repo_ordens = OrdensSqlite(banco)
    repo_auditoria = AuditoriaSqlite(banco)

    auditoria = ServicoAuditoria(banco, repo_auditoria, relogio)
    autenticacao = ServicoAutenticacao(repo_usuarios, auditoria, EmissorToken(chave_secreta), relogio)
    ordens = ServicoOrdem(banco, repo_contas, repo_ordens, bolsa, auditoria, relogio)
    return Servicos(banco, bolsa, relogio, repo_usuarios, repo_contas, repo_ordens,
                    repo_auditoria, auditoria, autenticacao, ordens)
