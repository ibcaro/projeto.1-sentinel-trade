"""Ordens de compra e venda: validações, reservas, envio à Bolsa e ciclo de vida."""
import uuid
from datetime import datetime, timezone
from decimal import Decimal
from typing import Callable, Optional

from ..dominio.estados import EstadoOrdem, validar_transicao
from ..dominio.excecoes import (AcessoNegado, BolsaIndisponivel, ErroDeDominio,
                                LimiteRiscoExcedido, MercadoFechado,
                                OrdemNaoEncontrada, PosicaoInsuficiente,
                                SaldoInsuficiente, TransicaoInvalida,
                                ValidacaoInvalida)
from ..dominio.modelos import Ordem, Perfil, TipoOrdem, Usuario
from ..dominio.validacao import (validar_ativo, validar_chave, validar_preco,
                                 validar_quantidade, validar_tipo)
from ..integracoes.bolsa import Bolsa
from ..persistencia.banco import Banco
from ..persistencia.repositorios import RepositorioContas, RepositorioOrdens
from .auditoria import ServicoAuditoria

TENTATIVAS_BOLSA = 3


class ServicoOrdem:
    def __init__(self, banco: Banco, contas: RepositorioContas, ordens: RepositorioOrdens,
                 bolsa: Bolsa, auditoria: ServicoAuditoria,
                 relogio: Callable[[], datetime] = lambda: datetime.now(timezone.utc),
                 tentativas: int = TENTATIVAS_BOLSA):
        self._banco = banco
        self._contas = contas
        self._ordens = ordens
        self._bolsa = bolsa
        self._auditoria = auditoria
        self._relogio = relogio
        self._tentativas = tentativas

    # ---------- Enviar ----------
    def enviar(self, investidor: Usuario, ativo, tipo, quantidade, preco,
               chave_idempotencia) -> Ordem:
        ativo = validar_ativo(ativo)
        tipo = validar_tipo(tipo)
        quantidade = validar_quantidade(quantidade)
        preco_centavos = validar_preco(preco)
        chave = validar_chave(chave_idempotencia)
        if investidor.perfil != Perfil.INVESTIDOR:
            raise AcessoNegado()

        with self._banco.transacao():
            existente = self._ordens.obter_por_chave(investidor.id, chave)
            if existente:  # mesma chave: devolve a ordem original, não executa de novo
                self._auditoria.registrar("ORDEM_DUPLICADA_IGNORADA", investidor.id,
                                          f"ordem={existente.id}")
                return existente
            if not self._contas.ativo_existe(ativo):
                raise ValidacaoInvalida("Ativo não cadastrado.")

            agora = self._relogio().isoformat()
            ordem = Ordem(id=str(uuid.uuid4()), investidor_id=investidor.id, ativo=ativo,
                          tipo=tipo, quantidade=quantidade, preco_centavos=preco_centavos,
                          chave_idempotencia=chave, estado=EstadoOrdem.PENDENTE,
                          motivo=None, criado_em=agora)
            self._ordens.criar(ordem, agora)
            self._auditoria.registrar("ORDEM_CRIADA", investidor.id,
                                      f"ordem={ordem.id} {tipo.value} {quantidade} {ativo}")
            try:
                self._validar_e_reservar(ordem)
            except ErroDeDominio as erro:
                self._transitar(ordem, EstadoOrdem.REJEITADA, erro.mensagem_publica)
                self._auditoria.registrar("ORDEM_REJEITADA", investidor.id,
                                          f"ordem={ordem.id} motivo={erro.mensagem_publica}")
                return ordem

        self._enviar_para_bolsa(ordem)
        return self._ordens.obter(ordem.id)

    def _validar_e_reservar(self, ordem: Ordem) -> None:
        if not self._bolsa.mercado_aberto():
            raise MercadoFechado()
        conta = self._contas.obter_conta(ordem.investidor_id)
        if conta is None:
            raise AcessoNegado()
        if ordem.valor_centavos > conta.limite_risco_centavos:
            raise LimiteRiscoExcedido()
        if ordem.tipo == TipoOrdem.COMPRA:
            if conta.saldo_centavos < ordem.valor_centavos:
                raise SaldoInsuficiente()
            self._contas.ajustar_conta(ordem.investidor_id, -ordem.valor_centavos, ordem.valor_centavos)
        else:
            posicao = self._contas.obter_posicao(ordem.investidor_id, ordem.ativo)
            disponivel = (posicao.quantidade - posicao.reservada) if posicao else 0
            if disponivel < ordem.quantidade:
                raise PosicaoInsuficiente()
            self._contas.ajustar_posicao(ordem.investidor_id, ordem.ativo, 0, ordem.quantidade)

    def _enviar_para_bolsa(self, ordem: Ordem) -> None:
        resultado: Optional[EstadoOrdem] = None
        for tentativa in range(1, self._tentativas + 1):
            try:
                resultado = self._bolsa.enviar_ordem(ordem.id, ordem.ativo, ordem.tipo,
                                                     ordem.quantidade, ordem.preco_centavos)
                break
            except BolsaIndisponivel:
                self._auditoria.registrar("BOLSA_TENTATIVA_FALHOU", ordem.investidor_id,
                                          f"ordem={ordem.id} tentativa={tentativa}")

        if resultado is None:  # esgotou as tentativas: ordem em falha e reserva devolvida
            with self._banco.transacao():
                self._transitar(ordem, EstadoOrdem.FALHA, "Bolsa indisponível.")
                self._liberar_reserva(ordem)
                self._auditoria.registrar("ORDEM_FALHA", ordem.investidor_id, f"ordem={ordem.id}")
            return

        with self._banco.transacao():
            self._transitar(ordem, EstadoOrdem.ENVIADA)
            self._auditoria.registrar("ORDEM_ENVIADA", ordem.investidor_id, f"ordem={ordem.id}")

        with self._banco.transacao():
            if resultado == EstadoOrdem.EXECUTADA:
                self._liquidar(ordem)
                self._transitar(ordem, EstadoOrdem.EXECUTADA)
                self._auditoria.registrar("ORDEM_EXECUTADA", ordem.investidor_id, f"ordem={ordem.id}")
            else:
                self._transitar(ordem, EstadoOrdem.REJEITADA, "Rejeitada pela Bolsa.")
                self._liberar_reserva(ordem)
                self._auditoria.registrar("ORDEM_REJEITADA", ordem.investidor_id,
                                          f"ordem={ordem.id} motivo=bolsa")

    # ---------- Cancelar ----------
    def cancelar(self, investidor: Usuario, ordem_id: str) -> Ordem:
        with self._banco.transacao():
            ordem = self._ordens.obter(ordem_id) if isinstance(ordem_id, str) else None
            if ordem is None or ordem.investidor_id != investidor.id:
                raise OrdemNaoEncontrada()
            validar_transicao(ordem.estado, EstadoOrdem.CANCELADA)
            if ordem.estado == EstadoOrdem.ENVIADA and not self._bolsa.cancelar_ordem(ordem.id):
                raise TransicaoInvalida("A Bolsa não aceitou o cancelamento.")
            self._transitar(ordem, EstadoOrdem.CANCELADA, "Cancelada pelo investidor.")
            self._liberar_reserva(ordem)
            self._auditoria.registrar("ORDEM_CANCELADA", investidor.id, f"ordem={ordem.id}")
            return ordem

    # ---------- Consultas ----------
    def consultar(self, investidor: Usuario) -> list[Ordem]:
        return self._ordens.listar_por_investidor(investidor.id)

    def consultar_carteira(self, investidor: Usuario) -> dict:
        conta = self._contas.obter_conta(investidor.id)
        if conta is None:
            raise AcessoNegado()
        return {
            "saldo": Decimal(conta.saldo_centavos) / 100,
            "reservado": Decimal(conta.reservado_centavos) / 100,
            "limite_risco": Decimal(conta.limite_risco_centavos) / 100,
            "posicoes": [{"ativo": p.ativo, "quantidade": p.quantidade, "reservada": p.reservada}
                         for p in self._contas.listar_posicoes(investidor.id)],
        }

    # ---------- Apoio ----------
    def _transitar(self, ordem: Ordem, novo: EstadoOrdem, motivo: Optional[str] = None) -> None:
        validar_transicao(ordem.estado, novo)
        self._ordens.atualizar_estado(ordem.id, novo, motivo, self._relogio().isoformat())
        ordem.estado = novo
        ordem.motivo = motivo

    def _liquidar(self, ordem: Ordem) -> None:
        if ordem.tipo == TipoOrdem.COMPRA:
            self._contas.ajustar_conta(ordem.investidor_id, 0, -ordem.valor_centavos)
            self._contas.ajustar_posicao(ordem.investidor_id, ordem.ativo, ordem.quantidade, 0)
        else:
            self._contas.ajustar_posicao(ordem.investidor_id, ordem.ativo,
                                         -ordem.quantidade, -ordem.quantidade)
            self._contas.ajustar_conta(ordem.investidor_id, ordem.valor_centavos, 0)

    def _liberar_reserva(self, ordem: Ordem) -> None:
        if ordem.tipo == TipoOrdem.COMPRA:
            self._contas.ajustar_conta(ordem.investidor_id, ordem.valor_centavos,
                                       -ordem.valor_centavos)
        else:
            self._contas.ajustar_posicao(ordem.investidor_id, ordem.ativo, 0, -ordem.quantidade)
