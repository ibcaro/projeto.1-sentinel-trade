"""Testes das regras do domínio (sem banco): estados, validação, segurança e Bolsa."""
import itertools
import unittest
from datetime import datetime, timedelta, timezone
from decimal import Decimal

from sentineltrade.dominio.estados import (ESTADOS_FINAIS, TRANSICOES, EstadoOrdem,
                                           pode_transitar, validar_transicao)
from sentineltrade.dominio.excecoes import (BolsaIndisponivel, TokenInvalido,
                                            TransicaoInvalida, ValidacaoInvalida)
from sentineltrade.dominio.modelos import Ordem, TipoOrdem
from sentineltrade.dominio.validacao import (validar_ativo, validar_chave,
                                             validar_codigo_mfa, validar_email,
                                             validar_preco, validar_quantidade,
                                             validar_tipo)
from sentineltrade.integracoes.bolsa import BolsaSimulada
from sentineltrade.servicos.seguranca import (EmissorToken, gerar_codigo,
                                              hash_senha, passo_atual,
                                              verificar_codigo, verificar_senha)

E = EstadoOrdem
T0 = datetime(2026, 11, 25, 12, 0, 0, tzinfo=timezone.utc)
SEGREDO = "JBSWY3DPEHPK3PXP"
CHAVE = "chave-de-teste-com-mais-de-32-caracteres!"
ATAQUES_SQL = ["'; DROP TABLE usuarios; --", "' OR '1'='1", "admin'--", "1; DELETE FROM ordens"]


class TestEstadosDaOrdem(unittest.TestCase):
    PERMITIDAS = {(E.PENDENTE, E.ENVIADA), (E.PENDENTE, E.REJEITADA), (E.PENDENTE, E.CANCELADA),
                  (E.PENDENTE, E.FALHA), (E.ENVIADA, E.EXECUTADA), (E.ENVIADA, E.REJEITADA),
                  (E.ENVIADA, E.CANCELADA), (E.ENVIADA, E.FALHA)}

    def test_todas_as_combinacoes_de_transicao(self):
        for origem, destino in itertools.product(EstadoOrdem, EstadoOrdem):
            with self.subTest(origem=origem.value, destino=destino.value):
                esperado = (origem, destino) in self.PERMITIDAS
                self.assertEqual(pode_transitar(origem, destino), esperado)

    def test_estados_finais_nao_mudam_mais(self):
        self.assertEqual(ESTADOS_FINAIS, {E.EXECUTADA, E.REJEITADA, E.CANCELADA, E.FALHA})
        for final in ESTADOS_FINAIS:
            self.assertEqual(TRANSICOES[final], frozenset())
            for destino in EstadoOrdem:
                with self.assertRaises(TransicaoInvalida):
                    validar_transicao(final, destino)

    def test_pendente_nao_vai_direto_para_executada(self):
        with self.assertRaises(TransicaoInvalida):
            validar_transicao(E.PENDENTE, E.EXECUTADA)

    def test_ordem_calcula_valor_em_centavos(self):
        o = Ordem("1", "u", "PETR4", TipoOrdem.COMPRA, 10, 3550, "chave-0001", E.PENDENTE, None, "x")
        self.assertEqual(o.valor_centavos, 35500)
        self.assertEqual(o.preco, Decimal("35.50"))


class TestValidacaoDeEntradas(unittest.TestCase):
    def test_ativo_valido_e_invalido(self):
        self.assertEqual(validar_ativo("PETR4"), "PETR4")
        for ruim in ["petr4", "PE", "PETR4PETR4PETR4", "PETR 4", "", None, 123]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_ativo(ruim)

    def test_quantidade(self):
        self.assertEqual(validar_quantidade(10), 10)
        for ruim in [0, -1, 1_000_001, 1.5, "10", True, None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_quantidade(ruim)

    def test_preco_vira_centavos(self):
        self.assertEqual(validar_preco("10.50"), 1050)
        self.assertEqual(validar_preco(Decimal("0.01")), 1)
        self.assertEqual(validar_preco(5), 500)

    def test_preco_invalido(self):
        for ruim in [0, -1, "abc", "10.505", "NaN", "Infinity", 1_000_001, True, None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_preco(ruim)

    def test_tipo_de_ordem(self):
        self.assertEqual(validar_tipo("COMPRA"), TipoOrdem.COMPRA)
        self.assertEqual(validar_tipo("VENDA"), TipoOrdem.VENDA)
        for ruim in ["compra", "TROCA", "", None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_tipo(ruim)

    def test_email(self):
        self.assertEqual(validar_email("Ana@Orion.com"), "ana@orion.com")
        for ruim in ["ana", "ana@", "@orion.com", "ana@orion", "a b@orion.com", None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_email(ruim)

    def test_chave_de_idempotencia_e_codigo_mfa(self):
        self.assertEqual(validar_chave("abc-12345_X"), "abc-12345_X")
        self.assertEqual(validar_codigo_mfa("012345"), "012345")
        for ruim in ["curta", "tem espaço aqui", "x" * 65, None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_chave(ruim)
        for ruim in ["12345", "1234567", "abcdef", "12 345", None]:
            with self.subTest(ruim=ruim), self.assertRaises(ValidacaoInvalida):
                validar_codigo_mfa(ruim)

    def test_tentativas_de_sql_injection_sao_barradas_na_entrada(self):
        for ataque in ATAQUES_SQL:
            with self.subTest(ataque=ataque):
                for validar in (validar_email, validar_ativo, validar_chave, validar_codigo_mfa):
                    with self.assertRaises(ValidacaoInvalida):
                        validar(ataque)


class TestSenhaEMfa(unittest.TestCase):
    def test_senha_vira_hash_com_sal(self):
        h1, h2 = hash_senha("Senha@12345"), hash_senha("Senha@12345")
        self.assertNotIn("Senha@12345", h1)
        self.assertNotEqual(h1, h2)

    def test_verificar_senha(self):
        h = hash_senha("Senha@12345")
        self.assertTrue(verificar_senha("Senha@12345", h))
        self.assertFalse(verificar_senha("senha@12345", h))
        self.assertFalse(verificar_senha("Senha@12345", "lixo"))

    def test_codigo_mfa_tem_seis_digitos_e_e_deterministico(self):
        codigo = gerar_codigo(SEGREDO, T0)
        self.assertRegex(codigo, r"^\d{6}$")
        self.assertEqual(codigo, gerar_codigo(SEGREDO, T0 + timedelta(seconds=5)))

    def test_codigo_muda_no_passo_seguinte(self):
        self.assertNotEqual(gerar_codigo(SEGREDO, T0), gerar_codigo(SEGREDO, T0 + timedelta(minutes=5)))

    def test_codigo_correto_e_aceito_e_devolve_o_passo(self):
        passo = verificar_codigo(SEGREDO, gerar_codigo(SEGREDO, T0), T0, 0)
        self.assertEqual(passo, passo_atual(T0))

    def test_codigo_so_pode_ser_usado_uma_vez(self):
        codigo = gerar_codigo(SEGREDO, T0)
        passo = verificar_codigo(SEGREDO, codigo, T0, 0)
        self.assertIsNone(verificar_codigo(SEGREDO, codigo, T0, passo))

    def test_codigo_antigo_expira(self):
        codigo = gerar_codigo(SEGREDO, T0)
        self.assertIsNone(verificar_codigo(SEGREDO, codigo, T0 + timedelta(minutes=5), 0))

    def test_codigo_errado_e_recusado(self):
        certo = gerar_codigo(SEGREDO, T0)
        errado = f"{(int(certo) + 1) % 1_000_000:06d}"
        self.assertIsNone(verificar_codigo(SEGREDO, errado, T0, 0))


class TestToken(unittest.TestCase):
    def setUp(self):
        self.emissor = EmissorToken(CHAVE)

    def test_token_valido(self):
        t = self.emissor.emitir("u1", "acesso", 900, T0)
        self.assertEqual(self.emissor.validar(t, "acesso", T0 + timedelta(minutes=14)), "u1")

    def test_token_expira_em_15_minutos(self):
        t = self.emissor.emitir("u1", "acesso", 900, T0)
        with self.assertRaises(TokenInvalido):
            self.emissor.validar(t, "acesso", T0 + timedelta(minutes=15))

    def test_token_adulterado_e_recusado(self):
        t = self.emissor.emitir("u1", "acesso", 900, T0)
        corpo, assinatura = t.split(".")
        for falso in (f"{corpo}.{assinatura[:-2]}xx", f"{corpo}x.{assinatura}", "lixo", "a.b.c", ""):
            with self.subTest(falso=falso), self.assertRaises(TokenInvalido):
                self.emissor.validar(falso, "acesso", T0)

    def test_token_de_outra_etapa_nao_serve(self):
        parcial = self.emissor.emitir("u1", "mfa", 300, T0)
        with self.assertRaises(TokenInvalido):
            self.emissor.validar(parcial, "acesso", T0)

    def test_token_assinado_com_outra_chave_e_recusado(self):
        outro = EmissorToken("outra-chave-secreta-com-mais-de-32-caracteres")
        with self.assertRaises(TokenInvalido):
            self.emissor.validar(outro.emitir("u1", "acesso", 900, T0), "acesso", T0)

    def test_token_nao_aceita_tipos_estranhos(self):
        for ruim in (None, 123, b"abc"):
            with self.subTest(ruim=ruim), self.assertRaises(TokenInvalido):
                self.emissor.validar(ruim, "acesso", T0)

    def test_chave_curta_e_recusada(self):
        with self.assertRaises(ValueError):
            EmissorToken("curta")


class TestBolsaSimulada(unittest.TestCase):
    def envio(self, bolsa, ordem_id="o1"):
        return bolsa.enviar_ordem(ordem_id, "PETR4", TipoOrdem.COMPRA, 1, 100)

    def test_executa_por_padrao(self):
        self.assertEqual(self.envio(BolsaSimulada()), E.EXECUTADA)

    def test_fora_do_ar_levanta_erro(self):
        with self.assertRaises(BolsaIndisponivel):
            self.envio(BolsaSimulada(fora_do_ar=True))

    def test_falha_nas_primeiras_tentativas_e_depois_responde(self):
        b = BolsaSimulada(falhas_iniciais=2)
        for _ in range(2):
            with self.assertRaises(BolsaIndisponivel):
                self.envio(b)
        self.assertEqual(self.envio(b), E.EXECUTADA)

    def test_mesma_ordem_enviada_duas_vezes_nao_duplica(self):
        b = BolsaSimulada()
        self.envio(b), self.envio(b)
        self.assertEqual(len(b.recebidas), 1)

    def test_nao_cancela_ordem_ja_executada(self):
        b = BolsaSimulada()
        self.envio(b)
        self.assertFalse(b.cancelar_ordem("o1"))


if __name__ == "__main__":
    unittest.main()
