"""Testes do sistema funcionando junto (serviços + banco SQLite em memória + Bolsa simulada)."""
import sqlite3
import unittest
from datetime import datetime, timedelta, timezone

from sentineltrade.dados_demo import cadastrar_usuario
from sentineltrade.dominio.estados import EstadoOrdem as E
from sentineltrade.dominio.excecoes import (AcessoNegado, CodigoMfaInvalido, ContaBloqueada,
                                            CredenciaisInvalidas, OrdemNaoEncontrada,
                                            TokenInvalido, TransicaoInvalida, ValidacaoInvalida)
from sentineltrade.dominio.modelos import Ordem, Perfil, TipoOrdem
from sentineltrade.integracoes.bolsa import BolsaSimulada
from sentineltrade.servicos.contexto import criar_servicos
from sentineltrade.servicos.seguranca import gerar_codigo

SENHA = "Senha@12345"
SEGREDO = "JBSWY3DPEHPK3PXP"
CHAVE_SECRETA = "chave-de-teste-com-mais-de-32-caracteres!"


class Relogio:
    def __init__(self):
        self.agora = datetime(2026, 11, 25, 12, 0, 0, tzinfo=timezone.utc)

    def __call__(self):
        return self.agora

    def avancar(self, **kw):
        self.agora += timedelta(**kw)


class Base(unittest.TestCase):
    def setUp(self):
        self.relogio = Relogio()
        self.bolsa = BolsaSimulada()
        self.s = criar_servicos(":memory:", CHAVE_SECRETA, bolsa=self.bolsa, relogio=self.relogio)
        self.s.repo_contas.criar_ativo("PETR4", "Petrobras")
        self.inv = cadastrar_usuario(self.s, "ana@orion.com", SENHA, Perfil.INVESTIDOR,
                                     saldo_centavos=10_000_000, limite_risco_centavos=5_000_000,
                                     segredo_mfa=SEGREDO)
        self.s.repo_contas.ajustar_posicao(self.inv.id, "PETR4", 100, 0)
        self.adm = cadastrar_usuario(self.s, "admin@orion.com", SENHA, Perfil.ADMINISTRADOR,
                                     segredo_mfa="KRSXG5CTMVRXEZLU")
        self._n = 0

    def chave(self):
        self._n += 1
        return f"chave-{self._n:04d}"

    def enviar(self, tipo="COMPRA", qtd=10, preco="10.00", chave=None, usuario=None):
        return self.s.ordens.enviar(usuario or self.inv, "PETR4", tipo, qtd, preco,
                                    chave or self.chave())

    def conta(self, usuario=None):
        return self.s.repo_contas.obter_conta((usuario or self.inv).id)

    def posicao(self):
        return self.s.repo_contas.obter_posicao(self.inv.id, "PETR4")

    def eventos(self):
        return [l.evento for l in self.s.repo_auditoria.todos_em_ordem()]

    def autenticar(self, usuario):
        parcial = self.s.autenticacao.login(usuario.email, SENHA)
        codigo = gerar_codigo(usuario.segredo_mfa, self.relogio())
        return self.s.autenticacao.verificar_mfa(parcial, codigo)


class TestAutenticacao(Base):
    def test_login_com_senha_correta_devolve_token_parcial(self):
        self.assertTrue(self.s.autenticacao.login("ana@orion.com", SENHA))

    def test_login_ignora_maiusculas_no_email(self):
        self.assertTrue(self.s.autenticacao.login("ANA@Orion.com", SENHA))

    def test_senha_errada_e_recusada(self):
        with self.assertRaises(CredenciaisInvalidas):
            self.s.autenticacao.login("ana@orion.com", "senha-errada-1")

    def test_email_inexistente_da_o_mesmo_erro_de_senha_errada(self):
        with self.assertRaises(CredenciaisInvalidas):
            self.s.autenticacao.login("ninguem@orion.com", SENHA)

    def test_conta_bloqueada_apos_5_falhas(self):
        for _ in range(4):
            with self.assertRaises(CredenciaisInvalidas):
                self.s.autenticacao.login("ana@orion.com", "senha-errada-1")
        with self.assertRaises(ContaBloqueada):
            self.s.autenticacao.login("ana@orion.com", "senha-errada-1")
        self.assertIn("CONTA_BLOQUEADA", self.eventos())

    def test_conta_bloqueada_recusa_ate_a_senha_correta(self):
        for _ in range(5):
            try:
                self.s.autenticacao.login("ana@orion.com", "senha-errada-1")
            except (CredenciaisInvalidas, ContaBloqueada):
                pass
        with self.assertRaises(ContaBloqueada):
            self.s.autenticacao.login("ana@orion.com", SENHA)

    def test_bloqueio_dura_15_minutos(self):
        for _ in range(5):
            try:
                self.s.autenticacao.login("ana@orion.com", "senha-errada-1")
            except (CredenciaisInvalidas, ContaBloqueada):
                pass
        self.relogio.avancar(minutes=14)
        with self.assertRaises(ContaBloqueada):
            self.s.autenticacao.login("ana@orion.com", SENHA)
        self.relogio.avancar(minutes=1, seconds=1)
        self.assertTrue(self.s.autenticacao.login("ana@orion.com", SENHA))

    def test_login_correto_zera_o_contador_de_falhas(self):
        for _ in range(3):
            with self.assertRaises(CredenciaisInvalidas):
                self.s.autenticacao.login("ana@orion.com", "senha-errada-1")
        self.s.autenticacao.login("ana@orion.com", SENHA)
        self.assertEqual(self.s.repo_usuarios.obter_por_id(self.inv.id).falhas_login, 0)

    def test_mfa_correto_libera_o_acesso(self):
        token = self.autenticar(self.inv)
        self.assertEqual(self.s.autenticacao.validar_token(token).id, self.inv.id)

    def test_mfa_errado_e_recusado(self):
        parcial = self.s.autenticacao.login("ana@orion.com", SENHA)
        certo = gerar_codigo(SEGREDO, self.relogio())
        errado = f"{(int(certo) + 1) % 1_000_000:06d}"
        with self.assertRaises(CodigoMfaInvalido):
            self.s.autenticacao.verificar_mfa(parcial, errado)
        self.assertIn("MFA_FALHA", self.eventos())

    def test_codigo_mfa_nao_pode_ser_reutilizado(self):
        parcial = self.s.autenticacao.login("ana@orion.com", SENHA)
        codigo = gerar_codigo(SEGREDO, self.relogio())
        self.s.autenticacao.verificar_mfa(parcial, codigo)
        parcial2 = self.s.autenticacao.login("ana@orion.com", SENHA)
        with self.assertRaises(CodigoMfaInvalido):
            self.s.autenticacao.verificar_mfa(parcial2, codigo)

    def test_token_parcial_nao_serve_como_token_de_acesso(self):
        parcial = self.s.autenticacao.login("ana@orion.com", SENHA)
        with self.assertRaises(TokenInvalido):
            self.s.autenticacao.validar_token(parcial)

    def test_token_de_acesso_expira_em_15_minutos(self):
        token = self.autenticar(self.inv)
        self.relogio.avancar(minutes=14)
        self.s.autenticacao.validar_token(token)
        self.relogio.avancar(minutes=1, seconds=1)
        with self.assertRaises(TokenInvalido):
            self.s.autenticacao.validar_token(token)

    def test_sql_injection_no_login_e_barrada_e_o_banco_continua_intacto(self):
        for ataque in ("' OR '1'='1", "admin'--", "'; DROP TABLE usuarios; --"):
            with self.assertRaises(ValidacaoInvalida):
                self.s.autenticacao.login(ataque, SENHA)
            with self.assertRaises(ValidacaoInvalida):
                self.s.autenticacao.login("ana@orion.com", "x" * 129)
        self.assertEqual(self.s.repo_usuarios.contar(), 2)

    def test_senha_nunca_e_guardada_em_texto_puro(self):
        self.assertNotIn(SENHA, self.s.repo_usuarios.obter_por_id(self.inv.id).senha_hash)


class TestOrdens(Base):
    def test_compra_executada_atualiza_saldo_e_posicao(self):
        o = self.enviar("COMPRA", 10, "10.00")
        self.assertEqual(o.estado, E.EXECUTADA)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000 - 10_000)
        self.assertEqual(self.conta().reservado_centavos, 0)
        self.assertEqual(self.posicao().quantidade, 110)

    def test_venda_executada_credita_saldo_e_reduz_posicao(self):
        o = self.enviar("VENDA", 40, "10.00")
        self.assertEqual(o.estado, E.EXECUTADA)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000 + 40_000)
        self.assertEqual((self.posicao().quantidade, self.posicao().reservada), (60, 0))

    def test_ciclo_de_vida_registrado_na_auditoria(self):
        self.enviar()
        for evento in ("ORDEM_CRIADA", "ORDEM_ENVIADA", "ORDEM_EXECUTADA"):
            self.assertIn(evento, self.eventos())

    def test_saldo_insuficiente_rejeita_a_ordem(self):
        pobre = cadastrar_usuario(self.s, "pobre@orion.com", SENHA, Perfil.INVESTIDOR,
                                  saldo_centavos=100_000, limite_risco_centavos=5_000_000)
        o = self.enviar("COMPRA", 100, "50.00", usuario=pobre)   # R$ 5.000 > R$ 1.000
        self.assertEqual(o.estado, E.REJEITADA)
        self.assertEqual(o.motivo, "Saldo insuficiente.")
        self.assertEqual(self.conta(pobre).saldo_centavos, 100_000)
        self.assertEqual(self.bolsa.tentativas, 0)

    def test_posicao_insuficiente_rejeita_a_venda(self):
        o = self.enviar("VENDA", 101, "10.00")
        self.assertEqual(o.estado, E.REJEITADA)
        self.assertEqual(o.motivo, "Posição insuficiente.")

    def test_limite_de_risco_excedido_rejeita(self):
        o = self.enviar("COMPRA", 1000, "100.00")   # R$ 100.000 > limite de R$ 50.000
        self.assertEqual(o.estado, E.REJEITADA)
        self.assertEqual(o.motivo, "Limite de risco excedido.")
        self.assertEqual(self.conta().saldo_centavos, 10_000_000)

    def test_ordem_no_limite_exato_e_aceita(self):
        self.assertEqual(self.enviar("COMPRA", 500, "100.00").estado, E.EXECUTADA)

    def test_mercado_fechado_rejeita(self):
        self.bolsa.aberta = False
        o = self.enviar()
        self.assertEqual(o.estado, E.REJEITADA)
        self.assertEqual(o.motivo, "Mercado fechado.")

    def test_ordem_duplicada_nao_executa_duas_vezes(self):
        a = self.enviar(chave="chave-repetida-1")
        b = self.enviar(chave="chave-repetida-1")
        self.assertEqual(a.id, b.id)
        self.assertEqual(len(self.s.ordens.consultar(self.inv)), 1)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000 - 10_000)
        self.assertEqual(len(self.bolsa.recebidas), 1)
        self.assertIn("ORDEM_DUPLICADA_IGNORADA", self.eventos())

    def test_mesma_chave_para_investidores_diferentes_e_permitida(self):
        outro = cadastrar_usuario(self.s, "bia@orion.com", SENHA, Perfil.INVESTIDOR,
                                  saldo_centavos=1_000_000, limite_risco_centavos=500_000)
        self.enviar(chave="chave-compartilhada")
        self.enviar(chave="chave-compartilhada", usuario=outro)
        self.assertEqual(len(self.bolsa.recebidas), 2)

    def test_banco_impede_duas_ordens_com_a_mesma_chave(self):
        o = self.enviar(chave="chave-unica-01")
        copia = Ordem("outro-id", self.inv.id, "PETR4", TipoOrdem.COMPRA, 1, 100,
                      "chave-unica-01", E.PENDENTE, None, "x")
        with self.assertRaises(sqlite3.IntegrityError):
            self.s.repo_ordens.criar(copia, "x")
        self.assertIsNotNone(o)

    def test_bolsa_fora_do_ar_deixa_a_ordem_em_falha_e_devolve_o_saldo(self):
        self.bolsa.fora_do_ar = True
        o = self.enviar("COMPRA", 10, "10.00")
        self.assertEqual(o.estado, E.FALHA)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000)
        self.assertEqual(self.conta().reservado_centavos, 0)
        self.assertEqual(self.bolsa.tentativas, 3)
        self.assertIn("ORDEM_FALHA", self.eventos())

    def test_bolsa_fora_do_ar_na_venda_devolve_a_posicao(self):
        self.bolsa.fora_do_ar = True
        self.assertEqual(self.enviar("VENDA", 10, "10.00").estado, E.FALHA)
        self.assertEqual((self.posicao().quantidade, self.posicao().reservada), (100, 0))

    def test_bolsa_se_recupera_na_terceira_tentativa(self):
        self.bolsa.falhas_restantes = 2
        o = self.enviar()
        self.assertEqual(o.estado, E.EXECUTADA)
        self.assertEqual(self.bolsa.tentativas, 3)
        self.assertEqual(len(self.bolsa.recebidas), 1)

    def test_bolsa_rejeita_e_a_reserva_volta(self):
        self.bolsa.resultado = E.REJEITADA
        o = self.enviar("COMPRA", 10, "10.00")
        self.assertEqual(o.estado, E.REJEITADA)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000)
        self.assertEqual(self.conta().reservado_centavos, 0)

    def test_ativo_nao_cadastrado_e_recusado(self):
        with self.assertRaises(ValidacaoInvalida):
            self.s.ordens.enviar(self.inv, "XXXX9", "COMPRA", 1, "10.00", self.chave())

    def test_entradas_invalidas_nao_criam_ordem(self):
        casos = [("PETR4", "COMPRA", 0, "10.00"), ("PETR4", "COMPRA", 1, "-5"),
                 ("PETR4", "TROCA", 1, "10.00"), ("'; DROP TABLE ordens;--", "COMPRA", 1, "10.00")]
        for ativo, tipo, qtd, preco in casos:
            with self.subTest(ativo=ativo, tipo=tipo), self.assertRaises(ValidacaoInvalida):
                self.s.ordens.enviar(self.inv, ativo, tipo, qtd, preco, self.chave())
        self.assertEqual(self.s.ordens.consultar(self.inv), [])

    def test_administrador_nao_envia_ordens(self):
        with self.assertRaises(AcessoNegado):
            self.enviar(usuario=self.adm)

    def test_consultar_lista_so_as_ordens_do_proprio_investidor(self):
        outro = cadastrar_usuario(self.s, "bia@orion.com", SENHA, Perfil.INVESTIDOR,
                                  saldo_centavos=1_000_000, limite_risco_centavos=500_000)
        self.enviar()
        self.enviar(usuario=outro)
        self.assertEqual(len(self.s.ordens.consultar(self.inv)), 1)

    def test_carteira_mostra_saldo_e_posicoes(self):
        self.enviar("COMPRA", 10, "10.00")
        c = self.s.ordens.consultar_carteira(self.inv)
        self.assertEqual(str(c["saldo"]), "99900")
        self.assertEqual(c["posicoes"], [{"ativo": "PETR4", "quantidade": 110, "reservada": 0}])


class TestCancelamento(Base):
    def criar_manual(self, estado, tipo=TipoOrdem.COMPRA):
        """Cria uma ordem direto no banco (com reserva), para testar estados intermediários."""
        o = Ordem(f"ordem-{estado.value}-{tipo.value}", self.inv.id, "PETR4", tipo, 10, 1000,
                  self.chave(), estado, None, self.relogio().isoformat())
        self.s.repo_ordens.criar(o, o.criado_em)
        if tipo == TipoOrdem.COMPRA:
            self.s.repo_contas.ajustar_conta(self.inv.id, -o.valor_centavos, o.valor_centavos)
        else:
            self.s.repo_contas.ajustar_posicao(self.inv.id, "PETR4", 0, o.quantidade)
        return o

    def test_cancela_ordem_pendente_e_devolve_a_reserva(self):
        o = self.criar_manual(E.PENDENTE)
        r = self.s.ordens.cancelar(self.inv, o.id)
        self.assertEqual(r.estado, E.CANCELADA)
        self.assertEqual(self.conta().saldo_centavos, 10_000_000)
        self.assertEqual(self.conta().reservado_centavos, 0)
        self.assertIn("ORDEM_CANCELADA", self.eventos())

    def test_cancela_venda_pendente_e_devolve_a_posicao(self):
        o = self.criar_manual(E.PENDENTE, TipoOrdem.VENDA)
        self.s.ordens.cancelar(self.inv, o.id)
        self.assertEqual(self.posicao().reservada, 0)

    def test_cancela_ordem_enviada_se_a_bolsa_aceitar(self):
        o = self.criar_manual(E.ENVIADA)
        self.assertEqual(self.s.ordens.cancelar(self.inv, o.id).estado, E.CANCELADA)

    def test_nao_cancela_ordem_enviada_se_a_bolsa_recusar(self):
        self.bolsa.aceita_cancelamento = False
        o = self.criar_manual(E.ENVIADA)
        with self.assertRaises(TransicaoInvalida):
            self.s.ordens.cancelar(self.inv, o.id)
        self.assertEqual(self.s.repo_ordens.obter(o.id).estado, E.ENVIADA)

    def test_nao_cancela_ordem_ja_executada(self):
        o = self.enviar()
        with self.assertRaises(TransicaoInvalida):
            self.s.ordens.cancelar(self.inv, o.id)

    def test_nao_cancela_ordem_de_outro_investidor(self):
        outro = cadastrar_usuario(self.s, "bia@orion.com", SENHA, Perfil.INVESTIDOR,
                                  saldo_centavos=1_000_000, limite_risco_centavos=500_000)
        o = self.criar_manual(E.PENDENTE)
        with self.assertRaises(OrdemNaoEncontrada):
            self.s.ordens.cancelar(outro, o.id)

    def test_cancelar_ordem_inexistente(self):
        with self.assertRaises(OrdemNaoEncontrada):
            self.s.ordens.cancelar(self.inv, "nao-existe")


class TestAuditoria(Base):
    def test_so_administrador_consulta_logs(self):
        with self.assertRaises(AcessoNegado):
            self.s.auditoria.consultar(self.inv)

    def test_administrador_consulta_e_a_consulta_fica_registrada(self):
        self.enviar()
        logs = self.s.auditoria.consultar(self.adm)
        self.assertTrue(logs)
        self.assertIn("LOGS_CONSULTADOS", self.eventos())

    def test_filtro_por_evento(self):
        self.enviar()
        logs = self.s.auditoria.consultar(self.adm, evento="ORDEM_EXECUTADA")
        self.assertTrue(logs)
        self.assertTrue(all(l.evento == "ORDEM_EXECUTADA" for l in logs))

    def test_filtro_malicioso_e_barrado(self):
        with self.assertRaises(ValidacaoInvalida):
            self.s.auditoria.consultar(self.adm, evento="X' OR '1'='1")

    def test_cadeia_de_hash_esta_integra(self):
        self.enviar(), self.enviar("VENDA", 5, "10.00")
        self.assertEqual(self.s.auditoria.verificar_integridade(), (True, None))

    def test_cada_registro_guarda_o_hash_do_anterior(self):
        self.enviar()
        logs = self.s.repo_auditoria.todos_em_ordem()
        for anterior, atual in zip(logs, logs[1:]):
            self.assertEqual(atual.hash_anterior, anterior.hash_registro)

    def test_banco_proibe_alterar_log(self):
        self.enviar()
        with self.assertRaises(sqlite3.DatabaseError):
            self.s.banco.executar("UPDATE logs_auditoria SET detalhes = 'x' WHERE id = 1")

    def test_banco_proibe_apagar_log(self):
        self.enviar()
        with self.assertRaises(sqlite3.DatabaseError):
            self.s.banco.executar("DELETE FROM logs_auditoria WHERE id = 1")

    def test_log_adulterado_e_detectado(self):
        self.enviar(), self.enviar()
        # simula um atacante com acesso direto ao banco que remove a proteção
        self.s.banco.executar("DROP TRIGGER logs_sem_update")
        self.s.banco.executar("UPDATE logs_auditoria SET detalhes = 'adulterado' WHERE id = 2")
        ok, invalido = self.s.auditoria.verificar_integridade()
        self.assertFalse(ok)
        self.assertEqual(invalido, 2)

    def test_log_removido_e_detectado(self):
        self.enviar(), self.enviar()
        self.s.banco.executar("DROP TRIGGER logs_sem_delete")
        self.s.banco.executar("DELETE FROM logs_auditoria WHERE id = 2")
        self.assertFalse(self.s.auditoria.verificar_integridade()[0])

    def test_logs_nao_guardam_senha_nem_codigo(self):
        self.autenticar(self.inv)
        for log in self.s.repo_auditoria.todos_em_ordem():
            self.assertNotIn(SENHA, log.detalhes)
            self.assertNotIn(gerar_codigo(SEGREDO, self.relogio()), log.detalhes)


if __name__ == "__main__":
    unittest.main()
